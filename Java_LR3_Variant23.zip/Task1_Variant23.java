import java.util.Arrays;
import java.util.Scanner;

public class Task1_Variant23 {
    // Варіант 23, завдання 1:
    // Надрукувати другий за величиною елемент масиву різних чисел.
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Введіть кількість елементів масиву (не менше 2): ");
        int n = sc.nextInt();

        if (n < 2) {
            System.out.println("Помилка: потрібно щонайменше 2 елементи.");
            return;
        }

        int[] a = new int[n];
        System.out.println("Введіть " + n + " різних цілих чисел:");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        int[] sorted = a.clone();
        Arrays.sort(sorted);

        // За умовою числа різні, тому другий найбільший — передостанній.
        System.out.println("Масив: " + Arrays.toString(a));
        System.out.println("Другий за величиною елемент: " + sorted[n - 2]);
    }
}
