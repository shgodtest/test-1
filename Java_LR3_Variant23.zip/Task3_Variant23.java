import java.util.Random;
import java.util.Scanner;

public class Task3_Variant23 {
    // Варіант 23, завдання 3:
    // 1) Кількість від'ємних елементів у кожному стовпці.
    // 2) Найменший елемент матриці та його індекси.
    // 3) Видалити заданий рядок квадратної матриці:
    //    наступні рядки зсуваються вгору, останній рядок заповнюється нулями.

    private static final int SIZE = 5;

    public static void fillMatrix(int[][] matrix, Random random) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                matrix[i][j] = random.nextInt(41) - 20; // -20..20
            }
        }
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int value : row) {
                System.out.printf("%5d", value);
            }
            System.out.println();
        }
    }

    public static void countNegativeByColumn(int[][] matrix) {
        System.out.println("Кількість від'ємних елементів у кожному стовпці:");
        for (int j = 0; j < matrix[0].length; j++) {
            int count = 0;
            for (int i = 0; i < matrix.length; i++) {
                if (matrix[i][j] < 0) {
                    count++;
                }
            }
            System.out.println("Стовпець " + j + ": " + count);
        }
    }

    public static void printMinimum(int[][] matrix) {
        int min = matrix[0][0];
        int minRow = 0;
        int minCol = 0;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] < min) {
                    min = matrix[i][j];
                    minRow = i;
                    minCol = j;
                }
            }
        }

        System.out.println("Найменший елемент матриці: " + min);
        System.out.println("Індекси (рядок, стовпець; індексація з 0): (" + minRow + ", " + minCol + ")");
    }

    public static void deleteRow(int[][] matrix, int rowToDelete) {
        for (int i = rowToDelete; i < matrix.length - 1; i++) {
            matrix[i] = matrix[i + 1].clone();
        }
        matrix[matrix.length - 1] = new int[matrix[0].length];
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        int[][] matrix = new int[SIZE][SIZE];

        fillMatrix(matrix, random);

        System.out.println("Початкова матриця:");
        printMatrix(matrix);

        countNegativeByColumn(matrix);
        printMinimum(matrix);

        System.out.print("Введіть номер рядка для видалення (1-" + SIZE + "): ");
        int row = sc.nextInt();
        if (row < 1 || row > SIZE) {
            System.out.println("Неправильний номер рядка.");
            return;
        }

        deleteRow(matrix, row - 1);

        System.out.println("Матриця після видалення рядка " + row + ":");
        printMatrix(matrix);
    }
}
