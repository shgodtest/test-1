import java.util.Arrays;
import java.util.Random;

public class Task2_Variant23 {
    // Варіант 23, завдання 2:
    // Масив із 200 елементів у діапазоні -150..100.
    // Знайти неперервну послідовність додатних чисел із максимальною сумою.
    public static void main(String[] args) {
        int[] a = new int[200];
        Random random = new Random();

        for (int i = 0; i < a.length; i++) {
            a[i] = random.nextInt(251) - 150; // -150..100 включно
        }

        int bestSum = 0;
        int bestStart = -1;
        int bestEnd = -1;

        int currentSum = 0;
        int currentStart = 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] > 0) {
                if (currentSum == 0) {
                    currentStart = i;
                }
                currentSum += a[i];

                if (currentSum > bestSum) {
                    bestSum = currentSum;
                    bestStart = currentStart;
                    bestEnd = i;
                }
            } else {
                currentSum = 0;
            }
        }

        System.out.println("Масив (200 елементів, діапазон -150..100):");
        System.out.println(Arrays.toString(a));

        if (bestStart == -1) {
            System.out.println("У масиві немає додатних елементів.");
        } else {
            System.out.println("Неперервна послідовність додатних чисел із максимальною сумою:");
            System.out.println(Arrays.toString(Arrays.copyOfRange(a, bestStart, bestEnd + 1)));
            System.out.println("Початковий індекс: " + bestStart);
            System.out.println("Кінцевий індекс: " + bestEnd);
            System.out.println("Максимальна сума: " + bestSum);
        }
    }
}
